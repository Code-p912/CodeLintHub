import os
import shutil
import subprocess
from pathlib import Path

TOOLS = {
    "pylint": ["pylint", "--score=n", "--output-format=text"],
    "flake8": ["flake8", "--format=default"],
    "bandit": ["bandit", "-r", "-f", "txt", "-q"]
}

TIMEOUTS = {
    "pylint": 20,
    "flake8": 15,
    "bandit": 20
}

def _tool_available(exe: str) -> bool:
    return shutil.which(exe) is not None

def _run_tool(cmd, cwd: str, timeout: int):
    try:
        result = subprocess.run(
            cmd,
            cwd=cwd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=timeout,
            check=False
        )
        out = result.stdout.strip()
        err = result.stderr.strip()
        code = result.returncode
        return {"ok": True, "stdout": out, "stderr": err, "returncode": code}
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": "Timeout"}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}

def run_linters_on_files(file_paths):
    """
    Run supported linters against each Python file path provided.
    Returns a structure: { filename: { tool: {...} } }
    """
    results = {}
    for path in file_paths:
        p = Path(path).resolve()
        cwd = str(p.parent)
        filename = p.name
        per_file = {}
        for tool, base_cmd in TOOLS.items():
            exe = base_cmd[0]
            if not _tool_available(exe):
                per_file[tool] = {
                    "ok": False,
                    "error": f"'{exe}' not found. Install it to enable {tool}.",
                    "output": "",
                    "returncode": None
                }
                continue
            cmd = base_cmd + [filename]
            run = _run_tool(cmd, cwd=cwd, timeout=TIMEOUTS.get(tool, 15))
            if run.get("ok"):
                out = run.get("stdout", "")
                err = run.get("stderr", "")
                per_file[tool] = {
                    "ok": True,
                    "output": out if out else (err or "No issues found."),
                    "returncode": run.get("returncode")
                }
            else:
                per_file[tool] = {
                    "ok": False,
                    "error": run.get("error", "Unknown error"),
                    "output": ""
                }
        results[filename] = per_file
    return results

def format_report_markdown_for_multiple(results: dict) -> str:
    lines = []
    lines.append("# CodeLintHub Report\n")
    for fname, tools in results.items():
        lines.append(f"## File: {fname}\n")
        for tool, res in tools.items():
            lines.append(f"### {tool}\n")
            if res.get("ok"):
                lines.append("```\n" + res.get("output","").strip() + "\n```")
            else:
                lines.append(f"**Error:** {res.get('error','Unknown error')}")
            lines.append("")
    return "\n".join(lines)