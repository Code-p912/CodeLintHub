# CodeLintHub (multi-file)

This variant of CodeLintHub accepts multiple `.py` files uploaded at once and/or a single pasted code snippet with a filename. It runs pylint, flake8, and bandit for each file and shows per-file, per-tool outputs. A combined Markdown report is available for download.

Run locally:
```
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
gunicorn -w 2 -b 0.0.0.0:5000 app:app
```

Security: same static-analysis-only approach; user code is never executed.