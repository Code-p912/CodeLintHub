#!/usr/bin/env python3
import os
import io
import json
import tempfile
import subprocess
from datetime import datetime
from pathlib import Path
from flask import Flask, render_template, request, jsonify, send_file, abort
from werkzeug.utils import secure_filename

from lint_utils import run_linters_on_files, format_report_markdown_for_multiple

MAX_CONTENT_LENGTH = 2 * 1024 * 1024  # 2 MB total per submission
ALLOWED_EXTENSIONS = {'.py'}

def create_app():
    app = Flask(__name__)
    app.config['MAX_CONTENT_LENGTH'] = MAX_CONTENT_LENGTH
    app.after_request(csp_headers)
    return app

def csp_headers(resp):
    resp.headers['Content-Security-Policy'] = (
        "default-src 'self'; "
        "script-src 'self' https://cdn.jsdelivr.net; "
        "style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; "
        "img-src 'self' data:; "
        "font-src 'self' https://cdn.jsdelivr.net; "
        "connect-src 'self'; "
        "object-src 'none'; frame-ancestors 'none'"
    )
    resp.headers['X-Content-Type-Options'] = 'nosniff'
    resp.headers['X-Frame-Options'] = 'DENY'
    resp.headers['Referrer-Policy'] = 'no-referrer'
    return resp

app = create_app()

def _allowed_file(path: str) -> bool:
    return Path(path).suffix.lower() in ALLOWED_EXTENSIONS

def _save_uploaded_files(files):
    tmpdir = tempfile.mkdtemp(prefix="codelinthub_")
    saved = []
    for f in files:
        filename = secure_filename(f.filename) or "snippet.py"
        if not filename.endswith(".py"):
            filename = filename + ".py"
        path = os.path.join(tmpdir, filename)
        # write safely as text
        with open(path, "w", encoding="utf-8", newline="\n") as fh:
            content = f.read().decode("utf-8", errors="replace") if isinstance(f.read(), bytes) else f.read()
            fh.write(content.replace("\r\n", "\n").replace("\r", "\n"))
        saved.append(path)
    return saved, tmpdir

@app.route("/", methods=["GET"])
def index():
    return render_template("index.html")

@app.route("/lint", methods=["POST"])
def lint():
    """
    Accepts either raw text (single 'code' with optional filename) or multiple file uploads ('files').
    Runs linting tools for each file and returns structured JSON results.
    """
    try:
        files = request.files.getlist("files")
        code = request.form.get("code", "", type=str)
        filename = request.form.get("filename", "snippet.py", type=str)

        if files and any(f.filename for f in files):
            # validate extensions and total size guard handled by flask config
            for f in files:
                if not _allowed_file(f.filename):
                    return jsonify({"ok": False, "error": "Only .py files are allowed."}), 400
            saved_paths, tmpdir = _save_uploaded_files(files)
        elif code:
            # single code snippet
            tmpdir = tempfile.mkdtemp(prefix="codelinthub_")
            safe_name = secure_filename(filename) or "snippet.py"
            if not safe_name.endswith(".py"):
                safe_name += ".py"
            path = os.path.join(tmpdir, safe_name)
            with open(path, "w", encoding="utf-8", newline="\n") as fh:
                fh.write(code.replace("\r\n", "\n").replace("\r", "\n"))
            saved_paths = [path]
        else:
            return jsonify({"ok": False, "error": "No code or files provided."}), 400

        results = run_linters_on_files(saved_paths)

        # Prepare a combined markdown report
        report_md = format_report_markdown_for_multiple(results)
        stamp = datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
        report_name = f"codelinthub_report_{stamp}.md"

        # persist to tempdir for download
        token = f"{stamp}_{os.getpid()}"
        token_dir = Path(tempfile.gettempdir()) / "codelinthub_reports"
        token_dir.mkdir(parents=True, exist_ok=True)
        token_path = token_dir / f"{token}.md"
        token_path.write_text(report_md, encoding="utf-8")

        return jsonify({"ok": True, "results": results, "download_token": token, "download_name": report_name})
    except Exception as e:
        return jsonify({"ok": False, "error": f"Server error: {e}"}), 500

@app.route("/download/<token>", methods=["GET"])
def download(token: str):
    if not token or any(ch for ch in token if ch not in "0123456789TZ_abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"):
        abort(400)
    token_path = Path(tempfile.gettempdir()) / "codelinthub_reports" / f"{token}.md"
    if not token_path.exists():
        abort(404)
    return send_file(str(token_path), as_attachment=True, download_name=request.args.get("name", "codelinthub_report.md"), mimetype="text/markdown; charset=utf-8")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)))